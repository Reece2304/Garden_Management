package com.Horted.app.Domain;

/**
 * Roles within the system
 * @author reece
 *
 */
public enum Role {
	Free,
	Admin, Premium
}
