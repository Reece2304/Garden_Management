package com.Horted.app;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HortedGardeningAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
